</div>

<center>
<p>
		</br>
		</br>
		<img src='image/roilles.png' width='200' height='100' >
		</br>
		
		Raison sociale :
		Roilles SA
		</br>
		Capital :
		Société anonyme au capital de 125 000€
		</br>
		Siège social : 15, place de la Liberté 18010 Bourges CEDEX
</p>
</center>

</body>

</html>